package com.example.my.domain.auth.controller;

import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class AuthController {

    @GetMapping("/auth/login")
    public ModelAndView login() {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("auth/login");
        return modelAndView;
    }

    @GetMapping("/auth/join")
    public ModelAndView join() {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("auth/join");
        return modelAndView;
    }

    @GetMapping("/auth/logout")
    public ModelAndView logout(HttpSession session) {

        // session안에 있는 데이터를 다 지우겠다.
        session.invalidate();

        ModelAndView modelAndView = new ModelAndView();
        // redirect는 뒤에 적은 주소(@GetMapping("/auth/login"))로 이동시키겠다 라는 뜻. 
        modelAndView.setViewName("redirect:/auth/login");
        return modelAndView;
    }
}
